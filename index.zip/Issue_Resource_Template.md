## Hello Contributers! <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="25px">

### This issue allows contributors to share resources which they use to learn and develop their skills and share with others.
:tulip:Contributors can share websites, youtube videos, courses which helped them build their development skills.

## TEMPLATE
> COPY everything BELOW this, from contributor's suggests start to end along with the "START" and "END" comment lines

<!------ ________ Contributor's suggest START ________  ------>
<pre>

         Your Name:

         Your Interests and Hobbies:

         Useful Resources:

                       * Resource 1:


                       * Resource 2:


                       * Resource 3:   

</pre>
<!------ ________ Contributor's suggest END ________  ------>

> COPY everything ABOVE this, from contributor suggest start to end along with the "START" and "END" comment lines

- **DO NOT** modify the TEMPLATE directly, make a copy and paste it below
- make sure there is one line of space above and below your card
- Paste **YOUR SUGGEST** directly at the end of this document

------------------------------------------------------------------------------------------------------------------------------------------------------------------


------------------------------------------------------------------------------------------------------------------------------------------------------------------






<!------ ________ Contributor's suggest START ________  ------>
<pre>

         Your Name: Jyotika

         Your Interests and Hobbies: Exploring Tech Related Stuffs,  Learnings to Implementation!!

         Useful Resources:heart_eyes::heart_eyes::

                       * An Awesome Resource to learn Git: <a href="https://git-scm.com/book/en/v2/">https://git-scm.com/book/en/v2/</a>


                       * Building First Android App: <a href="https://developer.android.com/training/basics/firstapp">https://developer.android.com/training/basics/firstapp</a>


                       *  Python for beginners: <a href="https://developers.google.com/edu/python/">https://developers.google.com/edu/python/</a>

</pre>
<!------ ________ Contributor's suggest END ________  ------>


------------------------------------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------------------------------------------------


<!------ ________ Contributor's suggest START ________  ------>
<pre>

         Your Name: Adarsh Tripathi

         Your Interests and Hobbies: Learning new things, Listening music and reading Quotes!!

         Useful Resources:

                       * An Awesome Resource to learn React for beginners: <a href="https://youtu.be/Ke90Tje7VS0
">https://youtu.be/Ke90Tje7VS0</a>


                       * Object oriented programming crash course:  <a href="https://www.freecodecamp.org/news/object-oriented-programming-crash-course/">https://www.freecodecamp.org/news/object-oriented-programming-crash-course/</a>


                       *  Python data science Crash Course: <a href="https://www.freecodecamp.org/news/python-data-science-course-matplotlib-pandas-numpy/">https://www.freecodecamp.org/news/python-data-science-course-matplotlib-pandas-numpy/</a>

</pre>
<!------ ________ Contributor's suggest END ________  ------>

------------------------------------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------------------------------------------------


<!------ ________ Contributor's suggest START ________  ------>
<pre>

         Your Name: Yash wandhare

         Your Interests and Hobbies:To learn deepest aspects a language can do.It seems strange but coding is my hobby.

         Useful Resources:

                       * Javascript tutorial for begginers:<a href="https://javascript30.com/">https://javascript30.com/</a>


                       * Best channel to learn css effects:<a href="https://www.youtube.com/channel/UCbwXnUipZsLfUckBPsC7Jog">https://www.youtube.com/channel/UCbwXnUipZsLfUckBPsC7Jog</a>


                       * Begginers guide for Front-end development:<a href="https://www.upwork.com/hiring/development/">https://www.upwork.com/hiring/development/beginners-guide-to-front-end-development/</a>

</pre>
<!------ ________ Contributor's suggest END ________  ------>


------------------------------------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------------------------------------------------


<!------ ________ Contributor's suggest START ________  ------>
<pre>

        Your Name: Aarushi

        Your Interests and Hobbies: learning new tecnical skills, reading books :)

        Useful Resources:

                      * Resource to learn javascript: <a href="https://javascript.info/">https://javascript.info/</a>


                      * Resource to begin with flutter developement: <a href="https://youtu.be/x0uinJvhNxI">https://youtu.be/x0uinJvhNxI</a>


                      * Resource to begin with coding/roadmap to coding: <a href="https://www.youtube.com/watch?v=RquBcwvgMbM">https://www.youtube.com/watch?v=RquBcwvgMbM</a>   

</pre>
<!------ ________ Contributor's suggest END ________  ------>


------------------------------------------------------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------------------------------------------------
<!------ ________ Contributor's suggest START ________  ------>
<pre>

         Your Name: Ana Carolina Arellano

         Your Interests and Hobbies: Going to museums and concerts!

         Useful Resources:

                       * Resource to learn GatsbyJS: <a href="https://www.gatsbyjs.com/tutorial/">https://www.gatsbyjs.com/tutorial/</a>


                       * Resource to know the react-bootstrap components: <a href="https://react-bootstrap.github.io/components/cards/">https://react-bootstrap.github.io/components/cards/</a>


                       * Resource to prepare for coding interviews: Book: Cracking the coding interview   

</pre>
<!------ ________ Contributor's suggest END ________  ------>
------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------


<!-- ________ Contributor's suggest START ________  -->
<pre>

         Your Name: Amninder Singh

         Your Interests and Hobbies: Playing chess,coding, watching anime, competative coding !!

         Useful Resources:

                       * An Awesome Resource to learn  Git: https://youtu.be/RGOj5yH7evk

                       * Resource to learn javascript: https://www.youtube.com/c/TheCodingTrain

                       *  Python for beginners: https://automatetheboringstuff.com/

</pre>
<!-- ________ Contributor's suggest END ________  -->
------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------


<!------ ________ Contributor's suggest START ________  ------>
<pre>

         Your Name: Charles

         Your Interests and Hobbies: Vue and lately it's been making art through code

         Useful Resources:

                       * Starting point for making art by coding: <https://dev.to/aspittel/intro-to-generative-art-2hi7>


                       * Simple guide for git (good reference): <https://rogerdudler.github.io/git-guide/> 


                       * Example of the design thought process behind a site: <https://design.theguardian.com/>

</pre>
<!------ ________ Contributor's suggest END ________  ------>